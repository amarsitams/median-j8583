package com.rumango.median.iso.dto;
//package com.rumango.median.iso.model;
//
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//
//@JsonAutoDetect
//public class ExternalSystemDetails {
//
//	public void setDetails(String systemName, String incomingMessageFormat, String outgoingMessageFormat,
//			String targetSystem, String incomingEndpoint, String outgoingEndpoint) {
//		this.systemName=systemName;
//		this.incomingMessageFormat=incomingMessageFormat;
//		this.outgoingMessageFormat=outgoingMessageFormat;
//		this.targetSystem=targetSystem;
//		this.incomingEndpoint=incomingEndpoint;
//		this.outgoingEndpoint=outgoingEndpoint;
//	}
//
//	private String systemName, incomingMessageFormat, outgoingMessageFormat, targetSystem, incomingEndpoint,
//			outgoingEndpoint;
//
//	public String getSystemName() {
//		return systemName;
//	}
//
//	public void setSystemName(String systemName) {
//		this.systemName = systemName;
//	}
//
//	public String getIncomingMessageFormat() {
//		return incomingMessageFormat;
//	}
//
//	public void setIncomingMessageFormat(String incomingMessageFormat) {
//		this.incomingMessageFormat = incomingMessageFormat;
//	}
//
//	public String getOutgoingMessageFormat() {
//		return outgoingMessageFormat;
//	}
//
//	public void setOutgoingMessageFormat(String outgoingMessageFormat) {
//		this.outgoingMessageFormat = outgoingMessageFormat;
//	}
//
//	public String getTargetSystem() {
//		return targetSystem;
//	}
//
//	public void setTargetSystem(String targetSystem) {
//		this.targetSystem = targetSystem;
//	}
//
//	public String getIncomingEndpoint() {
//		return incomingEndpoint;
//	}
//
//	public void setIncomingEndpoint(String incomingEndpoint) {
//		this.incomingEndpoint = incomingEndpoint;
//	}
//
//	public String getOutgoingEndpoint() {
//		return outgoingEndpoint;
//	}
//
//	public void setOutgoingEndpoint(String outgoingEndpoint) {
//		this.outgoingEndpoint = outgoingEndpoint;
//	}
//
//}
