package com.rumango.median.iso.test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

public class Demo {

	public static void main(String[] args) throws Exception {
		JAXBContext jc = JAXBContext.newInstance(Customer.class);

		Customer customer = new Customer();
		customer.getAddressMap().put("billing", "billingAddress");
		customer.getAddressMap().put("shipping", "shippingAddress");

		Marshaller marshaller = jc.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(customer, System.out);
	}

}