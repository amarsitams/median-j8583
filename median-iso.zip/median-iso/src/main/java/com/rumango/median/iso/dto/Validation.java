package com.rumango.median.iso.dto;
//package com.rumango.median.iso.model;
//
//public class Validation {
//	private int id;
//	private String field_description;
//	private Rule rule;
//	private boolean isDefault;
//	private String defalutValue;
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getField_description() {
//		return field_description;
//	}
//
//	public void setField_description(String field_description) {
//		this.field_description = field_description;
//	}
//
//	public Rule getRule() {
//		return rule;
//	}
//
//	public void setRule(Rule rule) {
//		this.rule = rule;
//	}
//
//	public boolean isDefault() {
//		return isDefault;
//	}
//
//	public void setDefault(boolean isDefault) {
//		this.isDefault = isDefault;
//	}
//
//	public String getDefalutValue() {
//		return defalutValue;
//	}
//
//	public void setDefalutValue(String defalutValue) {
//		if (this.isDefault)
//			this.defalutValue = defalutValue;
//		else
//			this.defalutValue = "";
//	}
//
//}
