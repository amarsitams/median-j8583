package com.rumango.median.iso.daoimpl;
//package com.rumango.median.iso.entity;
//
//import java.io.Serializable;
//
//import javax.persistence.Embeddable;
//
//@Embeddable
//public class RuleLovId implements Serializable {
//	private static final long serialVersionUID = 1L;
//	private String externlSystem;
//	private String targetSystem;
//	private int fieldNumber;
//
//	public String getExternlSystem() {
//		return externlSystem;
//	}
//
//	public void setExternlSystem(String externlSystem) {
//		this.externlSystem = externlSystem;
//	}
//
//	public String getTargetSystem() {
//		return targetSystem;
//	}
//
//	public void setTargetSystem(String targetSystem) {
//		this.targetSystem = targetSystem;
//	}
//
//	public int getFieldNumber() {
//		return fieldNumber;
//	}
//
//	public void setFieldNumber(int fieldNumber) {
//		this.fieldNumber = fieldNumber;
//	}
//}
