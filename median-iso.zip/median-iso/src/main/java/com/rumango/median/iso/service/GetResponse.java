package com.rumango.median.iso.service;

import java.util.Map;

public interface GetResponse {
	public String convertAndRespond(String stringMessage, Map<String, String> map);
	public String convertAndRespond(String stringMessage);
}
