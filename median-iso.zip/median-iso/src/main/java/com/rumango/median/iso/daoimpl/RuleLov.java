package com.rumango.median.iso.daoimpl;
//package com.rumango.median.iso.entity;
//
//import javax.persistence.EmbeddedId;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//
//@Entity
//@Table(name = "system_iso87_rule_lov")
//@JsonAutoDetect
//public class RuleLov {
//
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//
//	@EmbeddedId
//	private RuleLovId lovId;
//
//	private String fieldDescription;
//
//	private long lovValues;
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public String getFieldDescription() {
//		return fieldDescription;
//	}
//
//	public void setFieldDescription(String fieldDescription) {
//		this.fieldDescription = fieldDescription;
//	}
//
//	public long getLovValues() {
//		return lovValues;
//	}
//
//	public void setLovValues(long lovValues) {
//		this.lovValues = lovValues;
//	}
//}
