package com.rumango.median.iso.service;

public interface ValidationLogic {
	public String validate(int fieldNo, String currentValue);
}
