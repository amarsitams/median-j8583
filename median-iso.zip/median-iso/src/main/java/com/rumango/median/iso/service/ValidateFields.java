package com.rumango.median.iso.service;

import java.util.Map;

public interface ValidateFields {

	public Map<Integer, String> incoming(Map<Integer, String> isoMsg);

	public Map<Integer, String> outgoing(Map<Integer, String> isoMsg);

}
