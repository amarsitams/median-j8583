package com.rumango.median.iso.daoimpl;
//package com.rumango.median.iso.entity;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonAutoDetect;
//
//@Entity
//@Table(name = "mandatory_rules")
//@JsonAutoDetect
//public class MandatoryFields {
//
//	@Id
//	@GeneratedValue(strategy = GenerationType.IDENTITY)
//	private int id;
//	@Column(name = "field_no")
//	private int fieldNo;
//	@Column(name = "field_description")
//	private String fieldDescription;
//	@Column(name = "rule")
//	private String rule;
//	@Column(name = "isDefault")
//	private boolean isDefault;
//	@Column(name = "defalutValue")
//	private String defalutValue;
//
//	public int getId() {
//		return id;
//	}
//
//	public void setId(int id) {
//		this.id = id;
//	}
//
//	public int getFieldNo() {
//		return fieldNo;
//	}
//
//	public void setFieldNo(int fieldNo) {
//		this.fieldNo = fieldNo;
//	}
//
//	public String getFieldDescription() {
//		return fieldDescription;
//	}
//
//	public void setFieldDescription(String fieldDescription) {
//		this.fieldDescription = fieldDescription;
//	}
//
//	public String getRule() {
//		return rule;
//	}
//
//	public void setRule(String rule) {
//		this.rule = rule;
//	}
//
//	public boolean isDefault() {
//		return isDefault;
//	}
//
//	public void setDefault(boolean isDefault) {
//		this.isDefault = isDefault;
//	}
//
//	public String getDefalutValue() {
//		return defalutValue;
//	}
//
//	public void setDefalutValue(String defalutValue) {
//		this.defalutValue = defalutValue;
//	}
//
//}
